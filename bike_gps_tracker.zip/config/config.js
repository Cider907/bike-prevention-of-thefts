module.exports = {
    server_port : 3000,
    db_port : 5000,
    db_url :'mongodb+srv://cpfur18:spdlqj33@nodedb.daxkb.mongodb.net/NodeDB?retryWrites=true&w=majority'
}